#!/usr/bin/env bash
# ========================================================
# VLESS User Login Monitor
# ========================================================

clear
# Color definitions
NC='\033[0m'
GREEN='\033[0;32m'
RED='\033[0;31m'
CYAN='\033[0;36m'
BICyan='\033[1;96m'
BIWhite='\033[1;97m'

# Header
echo -e "\033[0;34m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\e[037;1m"
echo -e "\e[0;41;36m                   VLESS User Login Monitor                   \e[0m"
echo -e "\033[0;34m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\e[037;1m"

# Get VLESS users
readarray -t data < <(grep '###' /etc/xray/config.json | cut -d ' ' -f 2 | sort | uniq)

if [[ ${#data[@]} -eq 0 ]]; then
    echo "No VLESS users found!"
    echo -e "\033[0;34m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\e[037;1m"
    read -n 1 -s -r -p "Press any key to back on menu"
    menu
    exit 0
fi

active_users_found=false
first_user=true

for akun in "${data[@]}"; do
    [[ -z "$akun" ]] && continue
    
    # Create temporary files
    temp_log="/tmp/vless_${akun}_log.tmp"
    temp_ips="/tmp/vless_${akun}_ips.tmp"
    temp_unique_networks="/tmp/vless_${akun}_networks.tmp"
    
    # Get recent connections for this user
    grep -w "email: $akun" /var/log/xray/access.log | grep "accepted" | tail -n 100 > "$temp_log" 2>/dev/null
    
    if [[ -s "$temp_log" ]]; then
        active_users_found=true
        
        # Add separator between users
        if [[ "$first_user" == false ]]; then
            echo -e "\033[0;34m────────────────────────────────────────────────────────────────\e[037;1m"
        fi
        first_user=false
        
        # Extract all source IPs
        awk '{print $4}' "$temp_log" | cut -d':' -f1 | grep -v "^$" > "$temp_ips"
        
        # Group IPs by network prefix (first 3 octets) to handle NAT
        if [[ -s "$temp_ips" ]]; then
            # Create unique network prefixes (first 3 octets)
            awk -F'.' '{print $1"."$2"."$3}' "$temp_ips" | sort -u > "$temp_unique_networks"
        fi
        
        # Get user limits
        limit_ip="Unlimited"
        limit_quota="Unlimited"
        usage_quota="0"
        
        # IP Limit
        if [[ -f "/etc/xray/limit/ip/vless/$akun" ]] && limit_val=$(cat "/etc/xray/limit/ip/vless/$akun") && [[ -n "$limit_val" ]] && [[ "$limit_val" != "0" ]]; then
            limit_ip="$limit_val"
        fi
        
        # Quota Limit
        if [[ -f "/etc/xray/limit/quota/vless/$akun" ]] && limit_bytes=$(cat "/etc/xray/limit/quota/vless/$akun") && [[ "$limit_bytes" -gt 0 ]]; then
            limit_gb=$((limit_bytes / (1024 * 1024 * 1024)))
            [[ $limit_gb -gt 0 ]] && limit_quota="${limit_gb} GB"
        fi
        
        # Usage Quota
        if [[ -f "/etc/xray/usage/quota/vless/$akun" ]] && usage_bytes=$(cat "/etc/xray/usage/quota/vless/$akun") && [[ "$usage_bytes" -gt 0 ]]; then
            if [[ $usage_bytes -gt $((1024 * 1024 * 1024)) ]]; then
                usage_gb=$((usage_bytes / (1024 * 1024 * 1024)))
                usage_quota="${usage_gb} GB"
            else
                usage_mb=$((usage_bytes / (1024 * 1024)))
                usage_quota="${usage_mb} MB"
            fi
        fi
        
        # Last login time
        lastlogin=$(tail -n 1 "$temp_log" | cut -d " " -f 1,2)
        
        # Display user information
        echo -e "${BIWhite}Username        :${NC} ${GREEN}$akun${NC}"
        echo -e "${BIWhite}Last Login      :${NC} ${lastlogin}"
        echo -e "${BIWhite}IP Connections  :${NC} ${RED}$(wc -l < "$temp_unique_networks" 2>/dev/null || echo "0")${NC} / ${BICyan}$limit_ip${NC}"
        echo -e "${BIWhite}Data Usage      :${NC} ${RED}$usage_quota${NC} / ${BICyan}$limit_quota${NC}"
        
        # Display active networks with sample IPs
        if [[ -s "$temp_unique_networks" ]]; then
            echo -e "${BIWhite}Active Networks :${NC}"
            i=1
            while IFS= read -r network; do
                [[ -z "$network" ]] && continue
                
                # Get one sample IP from this network
                sample_ip=$(grep "^$network" "$temp_ips" | head -1)
                if [[ -z "$sample_ip" ]]; then
                    sample_ip=$(grep "$network" "$temp_ips" | head -1)
                fi
                
                # Get the last destination for this network
                dest_info=$(grep "$network" "$temp_log" | tail -n 1 | grep -oE '(tcp|udp):[^ ]+' | head -1)
                
                if [[ -n "$dest_info" ]]; then
                    echo -e "  ${BIWhite}Network $i:${NC} ${GREEN}$network.x${NC} ${BICyan}→${NC} ${CYAN}$dest_info${NC}"
                else
                    echo -e "  ${BIWhite}Network $i:${NC} ${GREEN}$network.x${NC}"
                fi
                ((i++))
            done < "$temp_unique_networks"
        else
            echo -e "${BIWhite}Active Networks :${NC} None"
        fi
        
        # Cleanup temporary files
        rm -f "$temp_log" "$temp_ips" "$temp_unique_networks"
    else
        # Cleanup temporary files even if no connections found
        rm -f "$temp_log" "$temp_ips" "$temp_unique_networks"
    fi
done

if [[ "$active_users_found" == false ]]; then
    echo "No active VLESS users found!"
fi

echo -e "\033[0;34m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\e[037;1m"
read -n 1 -s -r -p "Press any key to back on menu"
menu