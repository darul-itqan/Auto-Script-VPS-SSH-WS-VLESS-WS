#!/usr/bin/env bash

# --- Color Definitions ---
NC='\033[0m' # No Color
RED='\033[0;31m'
GREEN='\033[0;32m'
CYAN='\033[0;36m'
BICyan='\033[1;96m'
BIWhite='\033[1;97m'

# --- Function Definitions ---

# Delete All Recovery data
delall() {
     clear
    
    # Color definitions
    NC='\033[0m'
    GREEN='\033[0;32m'
    RED='\033[0;31m'
    YELLOW='\033[1;33m'
    CYAN='\033[0;36m'
    BICyan='\033[1;96m'
    BIWhite='\033[1;97m'
    
    echo -e "\033[0;34m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\e[037;1m"
    echo -e "\e[0;41;36m              DELETE ALL RECOVERY ACCOUNTS                  \e[0m"
    echo -e "\033[0;34m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\e[037;1m"
    echo ""
    echo -e "${YELLOW}WARNING: This action will permanently delete ALL recovery files${NC}"
    echo -e "${YELLOW}for both SSH and VLESS accounts that can be recovered later.${NC}"
    echo ""
    
    # Check if recovery directories exist
    ssh_recovery_exists=false
    vless_recovery_exists=false
    
    if [[ -d "/etc/xray/recovery/ssh" ]] && [[ -n "$(ls -A /etc/xray/recovery/ssh/ 2>/dev/null)" ]]; then
        ssh_recovery_exists=true
    fi
    
    if [[ -d "/etc/xray/recovery/vless" ]] && [[ -n "$(ls -A /etc/xray/recovery/vless/ 2>/dev/null)" ]]; then
        vless_recovery_exists=true
    fi
    
    # If no recovery files found
    if [[ "$ssh_recovery_exists" == false && "$vless_recovery_exists" == false ]]; then
        echo -e "${YELLOW}No recovery files found in any recovery directories.${NC}"
        echo -e "\033[0;34m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\e[037;1m"
        read -n 1 -s -r -p "Press any key to return to menu..."
        return 0
    fi
    
    # Display recovery files that will be deleted
    echo -e "${BIWhite}Recovery files that will be deleted:${NC}"
    echo -e "\033[0;34m─────────────────────────────────────────────────\e[037;1m"
    
    total_ssh=0
    total_vless=0
    
    if [[ "$ssh_recovery_exists" == true ]]; then
        echo -e "${BICyan}SSH Recovery Files:${NC}"
        ssh_files=$(ls /etc/xray/recovery/ssh/ 2>/dev/null)
        for file in $ssh_files; do
            if [[ -f "/etc/xray/recovery/ssh/$file" ]]; then
                echo -e "  ${GREEN}•${NC} $file"
                ((total_ssh++))
            fi
        done
        echo ""
    fi
    
    if [[ "$vless_recovery_exists" == true ]]; then
        echo -e "${BICyan}VLESS Recovery Files:${NC}"
        vless_files=$(ls /etc/xray/recovery/vless/ 2>/dev/null)
        for file in $vless_files; do
            if [[ -f "/etc/xray/recovery/vless/$file" ]]; then
                echo -e "  ${GREEN}•${NC} $file"
                ((total_vless++))
            fi
        done
    fi
    
    echo -e "\033[0;34m─────────────────────────────────────────────────\e[037;1m"
    echo -e "${BIWhite}Total files to delete:${NC}"
    echo -e "  SSH: ${RED}$total_ssh${NC} files"
    echo -e "  VLESS: ${RED}$total_vless${NC} files"
    echo -e "  ${BIWhite}TOTAL:${NC} ${RED}$((total_ssh + total_vless))${NC} files"
    echo ""
    
    # Confirmation
    echo -e "\033[0;34m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\e[037;1m"
    echo -e "${YELLOW}IMPORTANT:${NC}"
    echo -e "${YELLOW}Once deleted, these recovery files cannot be restored!${NC}"
    echo -e "\033[0;34m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\e[037;1m"
    echo ""
    
    read -rp $'\e[1;31mAre you absolutely sure you want to delete ALL recovery files? (yes/NO): \e[0m' confirm
    
    case "$confirm" in
        yes|YES|Yes|y|Y)
            echo ""
            echo -e "${YELLOW}Deleting recovery files...${NC}"
            echo ""
            
            deleted_count=0
            
            # Delete SSH recovery files
            if [[ "$ssh_recovery_exists" == true ]]; then
                echo -e "${BICyan}Deleting SSH recovery files...${NC}"
                ssh_files=$(ls /etc/xray/recovery/ssh/ 2>/dev/null)
                for file in $ssh_files; do
                    if [[ -f "/etc/xray/recovery/ssh/$file" ]]; then
                        rm -f "/etc/xray/recovery/ssh/$file"
                        echo -e "  ${GREEN}✓${NC} Deleted: $file"
                        ((deleted_count++))
                    fi
                done
                echo ""
            fi
            
            # Delete VLESS recovery files
            if [[ "$vless_recovery_exists" == true ]]; then
                echo -e "${BICyan}Deleting VLESS recovery files...${NC}"
                vless_files=$(ls /etc/xray/recovery/vless/ 2>/dev/null)
                for file in $vless_files; do
                    if [[ -f "/etc/xray/recovery/vless/$file" ]]; then
                        rm -f "/etc/xray/recovery/vless/$file"
                        echo -e "  ${GREEN}✓${NC} Deleted: $file"
                        ((deleted_count++))
                    fi
                done
                echo ""
            fi
            
            echo -e "\033[0;34m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\e[037;1m"
            echo -e "${GREEN}SUCCESS:${NC} ${BIWhite}Deleted ${RED}$deleted_count${NC} ${BIWhite}recovery files${NC}"
            echo -e "\033[0;34m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\e[037;1m"
            ;;
        *)
            echo ""
            echo -e "${YELLOW}Operation cancelled. No files were deleted.${NC}"
            echo -e "\033[0;34m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\e[037;1m"
            ;;
    esac
    
    read -n 1 -s -r -p "Press any key to return to menu..."
    menu
}

mdns() {
P='\e[0;35m'
B='\033[0;36m'
G='\033[0;32m'
NC='\e[0m'
N='\e[0m'
clear
echo -e "\e[36m╒══════════════════════════════════╕\033[0m"
echo -e " \E[0;41;36m                 CHANGE DNS                \E[0m"
echo -e "\e[36m╘══════════════════════════════════╛\033[0m
\033[1;37mDNS Changer By Rerechan02\033[0m
\033[1;37mTelegram : https://t.me/Rerechan02 \033[0m"
dnsfile="/root/.dns"
if test -f "$dnsfile"; then
udns=$(cat /root/.dns)
echo -e ""
echo -e "   Active DNS : \033[1;37m$udns\033[0m"
fi
echo -e "
 [\033[1;36m•1 \033[0m]  Temporary DNS
 [\033[1;36m•2 \033[0m]  Permanent DNS
 [\033[1;36m•3 \033[0m]  Reset DNS To Default
 [\033[1;36m•4 \033[0m]  Back To Main Menu"
echo ""
echo -e "\033[1;37mPress [ Ctrl+C ] • To-Exit-Script\033[0m"
echo ""
read -p "Select From Options [ 1 - 4 ] :  " dns
echo -e ""
case $dns in
1)
clear
echo -e "\033[1;37mTemporary DNS - Back To Default DNS After Rebooting VPS\033[0m"
echo ""
read -p "Please Insert DNS : " dns1
if [ -z $dns1 ]; then
echo ""
echo "Please Insert DNS !"
sleep 1
clear
mdns
fi
rm /etc/resolv.conf
touch /etc/resolv.conf
echo "$dns1" > /root/.dns
echo "nameserver $dns1" >> /etc/resolv.conf
systemctl restart resolvconf.service
echo ""
echo -e "\e[032;1mDNS $dns1 sucessfully insert in VPS\e[0m"
echo ""
cat /etc/resolv.conf
sleep 1
clear
mdns
;;
2)
clear
echo ""
read -p "Please Insert DNS : " dns2
if [ -z $dns2 ]; then
echo ""
echo "Please Insert DNS !"
sleep 1
clear
mdns
fi
rm /etc/resolv.conf
rm /etc/resolvconf/resolv.conf.d/head
touch /etc/resolv.conf
touch /etc/resolvconf/resolv.conf.d/head
echo "$dns2" > /root/.dns
echo "nameserver $dns2" >> /etc/resolv.conf
echo "nameserver $dns2" >> /etc/resolvconf/resolv.conf.d/head
systemctl restart resolvconf.service
echo ""
echo -e "\e[032;1mDNS $dns2 sucessfully insert in VPS\e[0m"
echo ""
cat /etc/resolvconf/resolv.conf.d/head
sleep 1
clear
mdns
;;
3)
clear
echo ""
read -p "Reset To Default DNS [Y/N]: " -e answer
if [ "$answer" = 'y' ] || [ "$answer" = 'Y' ]; then
rm /root/dns
echo ""
echo -e "[ ${G}INFO${NC} ] Delete Resolv.conf DNS"
echo "nameserver 8.8.8.8" > /etc/resolv.conf
sleep 1
echo -e "[ ${G}INFO${NC} ] Delete Resolv.conf.d/head DNS"
echo "nameserver 8.8.8.8" > /etc/resolvconf/resolv.conf.d/head
sleep 1
else if [ "$answer" = 'n' ] || [ "$answer" = 'N' ]; then
echo -e ""
echo -e "[ ${G}INFO${NC} ] Operation Cancelled By User"
sleep 1
fi
fi
clear
mdns
;;
4)
clear
menu
;;
*)
echo "Please enter an correct number"
clear
mdns
;;
esac
}


ins_hel() {

red='\e[1;31m'
green='\e[0;32m'
purple='\e[0;35m'
orange='\e[0;33m'
NC='\e[0m'
clear
if [[ -e /usr/local/sbin/helium ]]; then
     echo ""
     echo -e "${green}Ads Block Already Install${NC}"
     echo ""
	 read -n1 -r -p "Press any key to continue..."
	 menu
else

rm -rf /usr/local/sbin/helium
wget -q -O /usr/local/sbin/helium https://raw.githubusercontent.com/Rerechan02/sapphire/main/helium.sh
chmod +x /usr/local/sbin/helium
helium

fi

}

# Clear RAM Cache
function run_cc() {
    sudo sync
    sudo echo 1 > /proc/sys/vm/drop_caches
    sudo sync
    sudo echo 2 > /proc/sys/vm/drop_caches
    sudo sync
    sudo echo 3 > /proc/sys/vm/drop_caches
}


# --- Data Collection ---
# Fungsi untuk membaca data vnstat
read_vnstat_usage() {
  local interface=$1
  local today=$(vnstat -i "$interface" | grep "today" | awk '{print $8" "$9}')
  local yesterday=$(vnstat -i "$interface" | grep "yesterday" | awk '{print $8" "$9}')
  local this_month=$(vnstat -i "$interface" -m | grep "$(date +"%b '%y")" | awk '{print $9" "$10}')
  
  echo "$today;$yesterday;$this_month"
}

# Fungsi untuk mengonversi ke satuan MB
convert_to_mb() {
  local value=$1
  local unit=$2
  
  case $unit in
    B) echo "scale=6; $value / 1048576" | bc ;;
    KiB) echo "scale=6; $value / 1024" | bc ;;
    MiB) echo "$value" ;;
    GiB) echo "scale=6; $value * 1024" | bc ;;
    TiB) echo "scale=6; $value * 1048576" | bc ;;
    *) echo "0" ;;
  esac
}

# Mendapatkan semua interface
all_interfaces=$(vnstat --iflist | sed 's/Available interfaces: //')
if [ -z "$all_interfaces" ]; then
  echo "Tidak ada interface yang tersedia di vnstat."
  exit 1
fi

total_today=0
total_yesterday=0
total_month=0

for iface in $all_interfaces; do
  echo "Memproses interface: $iface"
  result=$(read_vnstat_usage "$iface")
  echo "Hasil untuk $iface: $result"
  
  today=$(echo "$result" | awk -F';' '{print $1}')
  yesterday=$(echo "$result" | awk -F';' '{print $2}')
  month=$(echo "$result" | awk -F';' '{print $3}')
  
  today_value=$(echo "$today" | awk '{print $1}')
  today_unit=$(echo "$today" | awk '{print $2}')
  
  yesterday_value=$(echo "$yesterday" | awk '{print $1}')
  yesterday_unit=$(echo "$yesterday" | awk '{print $2}')
  
  month_value=$(echo "$month" | awk '{print $1}')
  month_unit=$(echo "$month" | awk '{print $2}')
  
  total_today=$(echo "$total_today + $(convert_to_mb $today_value $today_unit)" | bc)
  total_yesterday=$(echo "$total_yesterday + $(convert_to_mb $yesterday_value $yesterday_unit)" | bc)
  total_month=$(echo "$total_month + $(convert_to_mb $month_value $month_unit)" | bc)
done

# Format hasil
format_usage() {
  local value=$1
  if (( $(echo "$value >= 1024" | bc -l) )); then
    echo "$(printf "%.2f" $(echo "$value / 1024" | bc)) GB"
  else
    echo "$(printf "%.2f" $value) MB"
  fi
}

ttoday=$(format_usage "$total_today")
tyest=$(format_usage "$total_yesterday")
tmon=$(format_usage "$total_month")

# TOTAL ACCOUNT COUNT
vls=$(cat /etc/xray/config.json | grep "###" | sort | uniq | wc -l)
ssh1="$(awk -F: '$3 >= 1000 && $1 != "nobody" {print $1}' /etc/passwd | wc -l)"

# SERVICE STATUS CHECKS
ressh="${RED}OFF${NC}"
[[ $(systemctl is-active dropbear) == "active" ]] && ressh="${GREEN}ON${NC}"

resngx="${RED}OFF${NC}"
[[ $(systemctl is-active nginx) == "active" ]] && resngx="${GREEN}ON${NC}"

resv2r="${RED}OFF${NC}"
[[ $(systemctl is-active xray) == "active" ]] && resv2r="${GREEN}ON${NC}"

# SYSTEM INFORMATION
DOMAIN=$(cat /etc/xray/domain)
cname=$(awk -F: '/model name/ {name=$2} END {print name}' /proc/cpuinfo | sed 's/^[ \t]*//;s/[ \t]*$//')
cores=$(awk -F: '/model name/ {core++} END {print core}' /proc/cpuinfo)
freq=$(awk -F: ' /cpu MHz/ {freq=$2} END {print freq}' /proc/cpuinfo | sed 's/^[ \t]*//;s/[ \t]*$//')
tram=$(free -m | awk 'NR==2 {print $2}')
up=$(uptime -p | sed 's/up //')
OS5=$(uname -o)
OS1=$(lsb_release -sd)
f1=$(lsb_release -sc)
frem=$(free -h | grep "Mem:" | awk '{print $3 "/" $2}')
freswp=$(free -h | grep "Swap:" | awk '{print $3 "/" $2}')
cpu=$(top -bn1 | grep "Cpu(s)" | awk '{print $2 "% user, " $4 "% sys, " $6 "% nice, " $8 "% idle"}')

# LAIN
xray_version=$(xray version | awk 'NR==1 {print $1, $2}')
IPVPS=$(curl -s ifconfig.me)


# --- Main Menu Display ---
clear
echo -e "${CYAN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}" | lolcat
echo -e "\E[41;1;37m                 ◎ VPS INFORMATION ◎                        \E[0m"
echo -e "${CYAN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}" | lolcat
echo -e "${BIWhite} OS         :${YELLOW} $OS1 [ $f1 ]${NC}"
echo -e "${BIWhite} CPU        :${YELLOW} $cname${NC}"
echo -e "${BIWhite} IP         :${YELLOW} $IPVPS${NC}"
echo -e "${BIWhite} Cores      :${YELLOW} $cores Cores @ $freq MHz${NC}"
echo -e "${BIWhite} Uptime     :${YELLOW} $up${NC}"
echo -e "${BIWhite} Domain     :${YELLOW} $DOMAIN${NC}"
echo -e "${CYAN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}" | lolcat
echo -e "${BIWhite} RAM Usage  :${YELLOW} $frem ${BIWhite} Total RAM :${YELLOW} $tram MB${NC}"
echo -e "${BIWhite} SWAP Usage :${YELLOW} $freswp${NC}"
echo -e "${BIWhite} CPU Usage  :${YELLOW} $cpu${NC}"
echo -e "${CYAN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}" | lolcat
echo -e "${BIWhite} Data Use :${BICyan} ${YELLOW} $ttoday ${NC}|${BICyan} ${YELLOW} $tyest ${NC}|${BICyan} ${YELLOW} $tmon${NC}"
echo -e "${CYAN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}" | lolcat
echo -e "${BIWhite} Accounts     : SSH (${YELLOW}$ssh1${NC}) ${NC}|${NC} VLESS (${YELLOW}$vls${NC})"
echo -e "${BIWhite} Services     : Dropbear ${BIWhite}($ressh) | Nginx ($resngx) | Xray ($resv2r)${NC}"
echo -e "${CYAN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}" | lolcat
echo -e "\E[41;1;37m              ◎ [  VPS MENU  ] ◎                        \E[0m"
echo -e "${CYAN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}" | lolcat
echo -e "1. Menu SSH Panel VPN"
echo -e "2. Menu VLESS Panel VPN"
echo -e "3. Subdomain & Certificate"
echo -e "4. Backup & Restore"
echo -e "5. Change Xray Core Version"
echo -e "6. Delete All Data Recovery"
echo -e "7. Check Streaming Support"
echo -e "8. VPS Speedtest"
echo -e "9. Change DNS Server"
echo -e "10. Install Ads Block [hard risk]"
echo -e "00. Change Server Banner"
echo -e "${CYAN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}" | lolcat
echo -e "${BIWhite} XRAY Version [${YELLOW} $xray_version ${NC}]                    "
echo -e "${CYAN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}" | lolcat

# --- User Input ---
read -p " SELECT OPTION FROM 0-8 : " mm
case $mm in
1) clear ; run_cc ; menu-ssh ;;
2) clear ; run_cc ; menu-vless ;;
3) clear ; run_cc ; menu-host ;;
4) clear ; run_cc ; menu-backup ;;
5) clear ; run_cc ; versi-xray ;;
6) clear ; run_cc ; delall ;;
7) clear ; run_cc ; stream-check ;;
8) clear ; run_cc ; echo -e "YES" | speedtest ;;
9) clear ; run_cc ; mdns ;;
10) clear ; run_cc ; ins_hel ;;
0) clear ; run_cc ; nano /etc/issue.net ;;
*) echo "Invalid option, please try again." ; sleep 1 ; menu ;;
esac
