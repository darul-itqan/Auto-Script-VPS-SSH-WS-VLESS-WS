#!/usr/bin/env bash
# ========================================================
# Author: Rerechan02
# License: This configuration is licensed for personal or internal use only.
#          Redistribution, resale, or reuse of this code in any form
#          without explicit written permission from the author is prohibited.
#          Selling this code or its derivatives is strictly forbidden.
# ========================================================

telegram_bot_token=$(cat /etc/xray/bot.key)
telegram_chatid=$(cat /etc/xray/client.id)

# Data
domain=$(cat /etc/xray/domain)
if [[ -s /root/.ip ]]; then
  ip=$(cat /root/.ip)
else
  ip=$(hostname -I | awk '{print $1}')
fi

cek_username() {
  if id "$1" &>/dev/null; then
    echo -e "\e[31m[404 Not Found]\e[0m Username '$1' sudah digunakan dalam sistem."
    exit 1
  elif [[ -e /etc/xray/database/ssh/$1.txt ]]; then
    echo -e "\e[31m[409 Conflict]\e[0m Username '$1' sudah ada dalam database."
    exit 1
  else
    echo -e "\e[32m[200 OK]\e[0m Username '$1' tersedia."
  fi
}

mkdir -p /etc/xray/limit/ip/ssh
mkdir -p /etc/xray/database/ssh

clear
echo -e "———————————————————"
echo -e " Create SSH Account "
echo -e "———————————————————"
read -p "Input Username : " username
cek_username "$username"
read -p "Input Password : " password
read -p "Expired (hari) : " masa
read -p "Limit IP (angka): " limit_ip

# validasi limit_ip hanya angka
if ! [[ $limit_ip =~ ^[0-9]+$ ]]; then
  echo -e "\e[31m[400 Bad Request]\e[0m Limit IP mesti berupa angka!"
  exit 1
fi

# Format expired
exp_system=$(date -d "$masa days" +%Y-%m-%d)            # untuk useradd
exp_display=$(date -d "$masa days" +"%d-%m-%Y %H:%M:%S") # untuk database & notif

# Tambah user
useradd -e "$exp_system" -M -N -s /bin/false "$username" && echo "$username:$password" | chpasswd

# Simpan limit ip
echo "$limit_ip" > /etc/xray/limit/ip/ssh/$username

# Simpan database akun
cat > /etc/xray/database/ssh/$username.txt <<EOF
username: $username
password: $password
limit_ip: $limit_ip
expired: $exp_display
EOF

# Notif Telegram
TEKS=$(cat <<EOF
<b>Success Create SSH Account</b>
<b>———————————————————</b>
<b>Domain:</b> <code>$domain</code> / <code>$ip</code>
<b>Username:</b> <code>$username</code>
<b>Password:</b> <code>$password</code>
<b>Limit IP:</b> <code>$limit_ip</code>
<b>———————————————————</b>
<b>Port OpenSSH:</b> <code>22</code>
<b>Port WS HTTP:</b> <code>80, 2082</code>
<b>Port WS TLS:</b> <code>443</code>
<b>Port BadVPN:</b> <code>7300</code>
<b>———————————————————</b>
<b>Config HTTP Custom:</b> <code>${domain}:1-65535@${username}:${password}</code>
<b>———————————————————</b>
<b>Payload:</b> <code>GET /ssh HTTP/1.1[crlf]Host: ${domain}[crlf]Upgrade: websocket[crlf][crlf]</code>
<b>———————————————————</b>
<b>Expired:</b> <code>$exp_display</code>
<b>———————————————————</b>
EOF
)

curl -s -X POST "https://api.telegram.org/bot$telegram_bot_token/sendMessage" \
    -d "chat_id=$telegram_chatid" \
    -d "parse_mode=HTML" \
    --data-urlencode "text=$TEKS" > /dev/null

clear
echo -e " Success Create SSH Account "
echo -e "———————————————————"
echo -e "Domain   : $domain / $ip "
echo -e "Username : $username "
echo -e "Password : $password "
echo -e "Limit IP : $limit_ip "
echo -e "———————————————————"
echo -e "Port OpenSSH : 22"
echo -e "Port WS HTTP : 80, 2082"
echo -e "Port WS TLS  : 443"
echo -e "Port BadVPN  : 7300"
echo -e "———————————————————"
echo -e "Config HTTP Custom: ${domain}:1-65535@${username}:${password}"
echo -e "———————————————————"
echo -e "Payload: GET /ssh HTTP/1.1[crlf]Host: ${domain}[crlf]Upgrade: websocket[crlf][crlf]"
echo -e "———————————————————"
echo -e "Expired  : $exp_display"
echo -e "———————————————————"