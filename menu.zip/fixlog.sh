> /var/log/syslog
> /var/log/auth.log
> /var/log/secure
> /var/log/xray/access.log
> /var/log/xray/error.log