#!/usr/bin/env bash

menu_vless() {
    clear
    echo -e "════════════════════════════════════════" 
    echo -e "         		[ VLESS MENU ]
    echo -e "════════════════════════════════════════" 
    echo -e " 1)  Create Account VLESS"
    echo -e " 2)  Trial Account VLESS"
    echo -e " 3)  Delete Account VLESS"
    echo -e " 4)  Renew Account VLESS"
    echo -e " 5)  Cek User Login VLESS"
    echo -e " 6)  List All VLESS Accounts"
    echo -e " 7)  Cek Config Account VLESS"
    echo -e " 8)  Recovery Account VLESS"
    echo -e "══════════════════════════════════" 
    echo -e " x)  MAIN MENU"
    echo -e "══════════════════════════════════" 
    echo -e ""
    read -p " Please select an option [1-9 or x]: " menu
    echo -e ""
    
    case $menu in
        1) add-vless ;;
        2) trial-vless ;;
        3) delete-vless ;;
        4) renew-vless ;;
        5) cek-vless ;;
        6) list-vless ;;
        7) config-vless ;;
        8) recovery-vless ;;
        x) menu ;;
        *) 
            echo -e "\e[31mInvalid option! Please try again.\e[0m"
            sleep 1
            menu_vless
            ;;
    esac
}

menu_vless