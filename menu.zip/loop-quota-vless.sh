#!/usr/bin/env bash

# Looping Quota Checker
for (( ; ; ))
do
quota-vless
sleep 2
done